-- test.hs Примеры к занятию 2.1: образцы для списков и простой парсинг

sum' []     = 0
sum' [x]    = x
sum' (x:xs) = x + sum' xs

printList []     = return ()
printList (x:xs) = print x >> printList xs

map' fn [x]    = [fn x]
map' fn (x:xs) = fn x : map' fn xs  --  map' fn (x:xs) = [fn x] ++ map' fn xs

{-
> map' (+1) [1,2,3]
[2,3,4]
-}

howmany []        = "no elements"
howmany [_]       = "1 element"
howmany [_, _]    = "2 elements"
howmany (_:_:_:_) = "3 or more elements"

--  quicksort from "Learn You a Haskell for a Great Good"

quicksort :: (Ord a) => [a] -> [a]  
quicksort [] = []  
quicksort (x:xs) =   
    let smallerSorted = quicksort [a | a <- xs, a <= x]  
        biggerSorted  = quicksort [a | a <- xs, a > x]  
    in  smallerSorted ++ [x] ++ biggerSorted  

-- lookup example + how to get a value from Maybe

keyValue = [(1,"one"), (2,"two"), (3,"three")]

getValue key xs | found == Nothing = "" 
                | otherwise        = let Just value = found 
                                     in value
    where
        found = lookup key xs
        
{-  getValue 2 keyValue
    "two"
    *Main> getValue 0 keyValue
    ""
-}

-- TAB-delimited file example

readTable :: FilePath -> IO [[Double]] -- Тип -- воизбежание ошибок read
readTable fp = readFile fp >>= return . map (map read) . map words . lines 
 
writeTable fp xss = writeFile fp (unlines $ map unwords $ map (map show) xss)

{-  test.dat
     0.72945        1.26398       -0.22314
    -0.72452        1.26046        0.24125
    -1.45790        0.00171       -0.21414
     ...            ...           ...
    
    ghci> readTable "test.dat"
    
    [[0.72945,1.26398,-0.22314]
    ,[-0.72452,1.26046,0.24125]
    ,[-1.4579,1.71e-3,-0.21414]
    , ...
    ]
    
    ghci> readTable "test.dat" >>= writeTable "test-.dat"
    или
    ghci> writeTable "test-.dat" =<< readTable "test.dat"
    
    test-.dat 
    0.72945 1.26398 -0.22314
    -0.72452 1.26046 0.24125
    -1.4579 1.71e-3 -0.21414
-}   
